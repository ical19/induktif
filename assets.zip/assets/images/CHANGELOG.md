Magenta version 1.0.0 initial build

<hr>
07-02-2021
- perbaikan gambar yang tidak muncul
- perbaikan display dengan ukuran layar berbeda (overflow fix)
- perbaikan url picture
- penambahan drawer
- perubahan algoritma deteksi page dari urutan element menjadi deteksi element '<th>'
- pengurangan spam code
- etc. lupa gw
